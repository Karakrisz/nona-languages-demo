$(document).ready(function () {
    $('#datetimepicker-start-time').datetimepicker({
        language: 'pt-BR'
    });
    $('#datetimepicker-end-time').datetimepicker({
        language: 'pt-BR'
    });
});